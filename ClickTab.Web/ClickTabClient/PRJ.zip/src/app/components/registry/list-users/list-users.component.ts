import { Component, OnInit } from '@angular/core';
import { UserDTO } from '../../../models/generics/user.model';

@Component({
  selector: 'app-list-users',
  templateUrl: './list-users.component.html',
  styleUrl: './list-users.component.scss'
})
export class ListUsersComponent implements OnInit{

  users:Array<UserDTO>=new Array<UserDTO>();
  ngOnInit(): void {
  


  }
  configureColumns(){
    
  }

}
