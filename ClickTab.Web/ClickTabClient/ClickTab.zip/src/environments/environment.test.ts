export const environment = {
  production: false,
  apiUrl: '',
  apiFullUrl: '',
  enableNotificationSystem: true
};
