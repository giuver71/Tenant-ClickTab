import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable, catchError, throwError } from "rxjs";
import { environment } from "../../environments/environment";
import { UserDTO, UserStatusEnum } from "../models/generics/user.model";

@Injectable({ providedIn: "root" })

/**
 * Servizio per utenti
 */
export class UserService {
  constructor(private http: HttpClient) {}

  /**
   * Metodo per ottenere tutti gli utenti dall'API
   */

  getAllUsers(): Promise<Array<UserDTO>> {
    return this.http.get<Array<UserDTO>>(environment.apiFullUrl + "/User/GetAllUsers").toPromise();
  }

  getFull(id: number): Promise<UserDTO> {
    return this.http.get<UserDTO>(environment.apiFullUrl + "/User/GetFull/" + id).toPromise();
  }

  saveUser(user: UserDTO): Promise<any> {
    return this.http.post<any>(environment.apiFullUrl + "/User", user).toPromise();
  }

  deleteUser(id: number): Promise<any> {
    return this.http.delete<any>(environment.apiFullUrl + "/User/" + id).toPromise();
  }

  firstLoginResetPassword(data: any): Promise<any> {
    return this.http.post<any>(environment.apiFullUrl + "/User/FirstLoginResetPassword", data).toPromise();
  }

  enableResetPassword(data: any): Promise<any> {
    return this.http.post<any>(environment.apiFullUrl + "/User/EnableResetPassword", data).toPromise();
  }

  checkToken(data: any): Observable<any> {
    return this.http.post<any>(environment.apiFullUrl + "/User/CheckToken", data).pipe(
      catchError((error: any) => {
        return throwError(() => error);
      })
    );
  }

  resetPassword(data: any): Promise<any> {
    return this.http.post<any>(environment.apiFullUrl + "/User/ResetPassword", data).toPromise();
  }

   getAllRolesUserFacilityHashed(id: number): Promise<string[]> {
    return this.http.get<string[]>(`${environment.apiFullUrl}/User/getAllRolesUserFacilityHashed/${id}`)
      .toPromise()
      .then(response => response ?? []);
  }

  changeStatus(status:UserStatusEnum,id:number){
    return this.http.get<any>(environment.apiFullUrl + "/User/ChangeStatus/"+status+'/'+id).toPromise();
  }
}
