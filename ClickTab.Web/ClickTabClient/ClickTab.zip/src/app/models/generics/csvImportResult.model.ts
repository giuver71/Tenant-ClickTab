export class CsvImportResultDTO 
{
  public HasErrors: boolean ;
  public FileBase64: string ;
  public FileContentType: string ; 
}