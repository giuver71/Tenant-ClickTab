export interface MockLookup {
  ID: number;
  Label: string;
}
