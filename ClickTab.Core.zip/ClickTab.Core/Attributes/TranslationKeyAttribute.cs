using System;
using System.Collections.Generic;
using System.Text;

namespace ClickTab.Core.Attributes
{
    public class TranslationKeyAttribute : Attribute
    {
        public string TranslationKey { get; set; }
    }
}
