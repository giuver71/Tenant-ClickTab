using EQP.EFRepository.Core.Services;
using System;
using System.Collections.Generic;
using System.Text;

namespace ClickTab.Core.HelperService
{
    public class EQPDictionaryManagerService : DictionaryManagerService
    {
        public EQPDictionaryManagerService()
        {
        }
    }
}
