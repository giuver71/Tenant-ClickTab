using System;
using System.Collections.Generic;
using System.Text;

namespace ClickTab.Core.HelperClass
{
    public class EqpFile
    {
        public string Name { get; set; }
        public string Extension { get; set; }
        public byte[] File { get; set; }
    }
}
