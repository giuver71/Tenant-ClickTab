﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClickTab.Core.DAL.Enums
{
    [Flags]
    public enum SystemRole
    {
        ADMIN = 1,
        USER = 2
    }
}
